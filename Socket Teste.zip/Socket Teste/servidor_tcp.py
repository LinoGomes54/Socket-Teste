import socket

# Configurações do Servidor TCP
TCP_IP = '127.0.0.1'  # Endereço IP do servidor
TCP_PORT = 5006       # Porta onde o servidor escutará
BUFFER_SIZE = 1024    # Tamanho do buffer de leitura

# Inicializa o socket TCP
tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcp_server_socket.bind((TCP_IP, TCP_PORT))  # Liga o socket ao endereço IP e porta
tcp_server_socket.listen(1)  # Escuta conexões TCP, permitindo apenas uma conexão

print(f"Servidor TCP escutando em {TCP_IP}:{TCP_PORT}")

# Aceita conexões TCP
conn, addr = tcp_server_socket.accept()  # Aceita uma conexão
print(f"Conexão estabelecida com {addr}")

# Loop para receber dados continuamente
while True:
    data = conn.recv(BUFFER_SIZE)  # Recebe os dados do cliente TCP
    if not data:
        break  # Se não houver mais dados, sai do loop
    print(f"Recebido no TCP: {data.decode()}")

    # Envia os dados recebidos para o Cliente UDP
    udp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    UDP_IP = '127.0.0.1'  # Endereço IP do Cliente UDP
    UDP_PORT = 5008       # Porta onde o Cliente UDP estará escutando
    udp_client_socket.sendto(data, (UDP_IP, UDP_PORT))  # Envia a mensagem via UDP

    conn.send(b"Mensagem enviada via UDP")  # Envia uma resposta para o cliente TCP

conn.close()  # Fecha a conexão TCP
