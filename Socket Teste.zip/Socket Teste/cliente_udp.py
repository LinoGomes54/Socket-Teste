import socket

# Configurações do Cliente UDP
UDP_IP = '127.0.0.1'
UDP_PORT = 5008
BUFFER_SIZE = 1024

# Inicializa o socket UDP
udp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_client_socket.bind((UDP_IP, UDP_PORT))

print(f"Cliente UDP escutando em {UDP_IP}:{UDP_PORT}")

# Loop para receber dados
while True:
    data, addr = udp_client_socket.recvfrom(BUFFER_SIZE)
    print(f"Recebido via UDP: {data.decode()}")


