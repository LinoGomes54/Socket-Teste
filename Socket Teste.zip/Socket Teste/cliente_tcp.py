import socket

# Configurações do Cliente TCP
TCP_IP = '127.0.0.1'  # Endereço do servidor TCP
TCP_PORT = 5006       # Porta do servidor TCP
BUFFER_SIZE = 1024    # Tamanho do buffer de leitura

# Inicializa o socket TCP
tcp_client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("Ola cliente TCP! Digite'sair' para encerrar)")


# Tenta se conectar ao servidor TCP
tcp_client_socket.connect((TCP_IP, TCP_PORT))
print(f"Conectado ao servidor TCP {TCP_IP}:{TCP_PORT}")

while True:
    # Enviar uma mensagem para o servidor
    message = input("Mensagem: ")
    if message.lower() == 'sair':
        break

    tcp_client_socket.send(message.encode())

    # Receber uma resposta do servidor
    data = tcp_client_socket.recv(BUFFER_SIZE)
    #print(f"Recebido do servidor: {data.decode()}")

try:
    print("Erro: Não foi possível conectar ao servidor TCP. Verifique se o servidor está rodando.")

except:
    # Fechar o socket
    tcp_client_socket.close()
